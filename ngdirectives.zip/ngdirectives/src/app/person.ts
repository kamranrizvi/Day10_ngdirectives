export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Kamran', gender: 'Male'},
    { id: 2, name: 'Suhel', gender: 'Male' },
    { id: 3, name: 'Farhan', gender: 'Male' },
    { id: 4, name: 'Faraz',gender: 'Male'}
  ];
  